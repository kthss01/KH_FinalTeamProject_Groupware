package com.kh.mybatis.member.model.dao;

import org.apache.ibatis.session.SqlSession;

import com.kh.mybatis.member.model.vo.Member;

public class MemberDao {

	public static Member loginMember(SqlSession sqlSession, Member m) throws Exception{
		
		Member loginUser = null;
		loginUser = sqlSession.selectOne("memberMapper.loginMember", m);
		
		return loginUser;
	}

	public int insertMember(SqlSession sqlSession, Member m) throws Exception {
		
		return sqlSession.insert("memberMapper.insertMember", m);
	}

}
